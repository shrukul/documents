/*
 * heuristic.cpp
 *
 * Implementaion defined in the header file.
 *
 * Copyright (C) Sat Feb 11 2006 Valentin Koch & Michael Henderson
 */

#include "heuristic.h"
