/*
 * search.cpp
 *
 * base class for the graph search algorithms
 *
 * Copyright (C) Sat Feb 11 2006 Valentin Koch & Michael Henderson
 */

#include "search.h"

