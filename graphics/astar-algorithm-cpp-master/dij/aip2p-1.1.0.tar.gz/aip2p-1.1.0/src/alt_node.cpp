/*
 * alt_node.cpp
 *
 * A comment stating what the declarations in it have in common,
 * references to manuals, general hints for maintenance, etc.
 *
 * Copyright (C) Sat Feb 11 2006 Valentin Koch & Michael Henderson
 */

#include "alt_node.h"

/**
 * Constructor
 */
